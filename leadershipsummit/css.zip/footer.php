
<body>
   
        <div class="all_content">
            <div class="contacts">
                <p class="emails"><i class="det fas fa-envelope"></i>&nbsp leadership.summit@xaviers.edu.in</p>
            <!--    <p class="contact"><i class="det fas fa-phone-square"></i>&nbsp 91xxxxxxxx</p>-->
                <p class="location"><i class="det fas fa-map-marker-alt"></i>&nbsp St. Xavier's College Autonomous</p>
            </div>
            
            <div class="iconss" >
                <a href="#"><i class="ic fab fa-facebook-f"   ></i></a>
                <a href="#"><i class="ic fab fa-instagram  "></i></a>
                <a href="#"><i class="ic fab fa-linkedin-in  "></i></a>
                <a href="#"><i class="ic fab fa-twitter "></i></i></a>
            </div>                    
         
    </div>
</body>
